---
title: 시계탑의 기차
title_latin: Sigyetap-ui Gicha
author: 정하은
author_latin: Jung Ha-eun
first_published: 1978
edition: 1986
---

# 시계탑의 기차

*Sigyetap-ui Gicha*

정하은(Jung Ha-eun) 지음

초판 1978년 / 개정판 1986년

## 책 소개

오랫동안 말을 끊은 두 자매는 몇 해 동안 국경 근처의 차밭을 피해 왔다. 그러나 강줄기가 하룻밤 사이에 바뀌자 모든 것이 다시 떠오른다.

시간이 한 장소를 바꾸는 방식에 관한 조용한 소설.
