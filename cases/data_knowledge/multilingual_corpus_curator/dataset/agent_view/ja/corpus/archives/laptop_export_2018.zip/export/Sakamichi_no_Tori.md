---
title: 坂道の鳥
title_latin: Sakamichi no Tori
author: 小林蓮
author_latin: Kobayashi Ren
first_published: 1999
---

# 坂道の鳥

*Sakamichi no Tori*

小林蓮（Kobayashi Ren） 著

初版 1999年

## 内容紹介

四十年遅れの手紙が届くとき、廃線になった鉄道の終着駅に住む夫を亡くした養蜂家は、何を残すべきかを決めなければならない。

時間が場所を変えていくことをめぐる静かな長編。
